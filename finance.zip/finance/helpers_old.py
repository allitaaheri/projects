import requests
import os
from flask import redirect, render_template, session
from functools import wraps


import re
from flask import render_template

def apology(message, code=400):
    """Render message as an apology to user."""
    def escape(s):
        """
        Escape special characters.
        """
        for old, new in [("-", "--"), (" ", "-"), ("_", "__"), ("?", "~q"), ("%", "~p"),
                         ("#", "~h"), ("/", "~s"), ("\"", "''")]:
            s = s.replace(old, new)
        return s
    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.

    https://flask.palletsprojects.com/en/latest/patterns/viewdecorators/
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function


def lookup(symbol):
    """Look up quote for symbol using an API."""

    # Contact API
    try:
        api_key = os.getenv("API_KEY")  # Ensure API key is stored securely
        url = f"https://api.polygon.io/v2/aggs/ticker/{symbol.upper()}/prev?adjusted=true&apiKey={api_key}"

        response = requests.get(url)
        response.raise_for_status()

    except requests.RequestException:
        # Return None if the API request fails
        return None

    # Parse the API response
    try:
        stock_data = response.json()

        # Ensure the response contains the required data
        if "results" not in stock_data or len(stock_data["results"]) == 0:
            return None

        # Get the first result (the most recent closing price)
        result = stock_data["results"][0]

        return {
            "name": symbol.upper(),  # The symbol itself
            "price": float(result["c"]),  # Closing price
            "symbol": symbol.upper()
        }

    except (KeyError, TypeError, ValueError):
        # Return None if there is an issue with the response structure
        return None


def usd(value):
    """Format value as USD."""
    return f"${value:,.2f}"

import os
import requests
from cs50 import SQL
from flask import g, Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")  # Ensure you are using finance.db

@app.before_request
def load_user_cash():
    """Load user's available cash for all pages."""
    if "user_id" in session:
        rows = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])
        if len(rows) > 0:
            g.user_cash = rows[0]["cash"]
        else:
            g.user_cash = 0  # Default to 0 if no cash data
    else:
        g.user_cash = 0  # If not logged in, default to 0


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks and cash balance."""
    # Fetch user cash
    user_id = session["user_id"]
    rows = db.execute("SELECT cash FROM users WHERE id = ?", user_id)
    cash = rows[0]["cash"]

    # Fetch portfolio
    transactions = db.execute("SELECT symbol, SUM(shares) AS total_shares FROM transactions WHERE user_id = ? GROUP BY symbol", user_id)
    portfolio = []
    total_portfolio_value = 0

    for transaction in transactions:
        if transaction["total_shares"] > 0:  # Only include stocks with shares
            stock = lookup(transaction["symbol"])
            total = stock["price"] * transaction["total_shares"]
            portfolio.append({
                "symbol": transaction["symbol"],
                "shares": transaction["total_shares"],
                "price": usd(stock["price"]),
                "total": usd(total)
            })
            total_portfolio_value += total

    # Calculate total value (cash + portfolio)
    total_value = cash + total_portfolio_value

    # Render index.html with portfolio, cash, and total value
    return render_template("index.html", portfolio=portfolio, cash=usd(cash), total_value=usd(total_value))


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    if request.method == "POST":
        symbol = request.form.get("symbol")
        shares = request.form.get("shares")

        # Ensure symbol was provided
        if not symbol:
            return apology("must provide symbol", 400)

        # Ensure shares is a valid number
        if not shares or not shares.isdigit() or int(shares) <= 0:
            return apology("must provide positive number of shares", 400)

        # Lookup stock data
        stock = lookup(symbol)
        if stock is None:
            return apology("invalid symbol", 400)

        # Calculate cost and ensure the user can afford it
        shares = int(shares)
        cost = float(stock["price"]) * shares  # Calculate total cost of the shares

        # Fetch user's current cash
        rows = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])
        cash = float(rows[0]["cash"])

        # Check if user can afford the purchase
        if cash < cost:
            return apology("can't afford", 400)

        # Update user's cash and record the transaction
        db.execute("UPDATE users SET cash = cash - ? WHERE id = ?", cost, session["user_id"])
        db.execute("INSERT INTO transactions (user_id, symbol, shares, price, transacted) VALUES (?, ?, ?, ?, datetime('now'))",
                   session["user_id"], stock["symbol"], shares, stock["price"])

        # Redirect to index after successful purchase
        return redirect("/")

    else:
        return render_template("buy.html")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    user_id = session["user_id"]

    # Fetch the user's transaction history
    transactions = db.execute("SELECT symbol, shares, price, transacted FROM transactions WHERE user_id = ? ORDER BY transacted DESC", user_id)

    # Fetch the user's current cash balance
    rows = db.execute("SELECT cash FROM users WHERE id = ?", user_id)
    cash = rows[0]["cash"]

    # Render the history page with the transactions and the current cash balance
    return render_template("history.html", transactions=transactions, cash=usd(cash))


@app.route("/login", methods=["GET", "POST"])
def login():
    session.clear()
    if "user_id" in session:
        return render_template("login.html")

    if request.method == "POST":
        # Get form inputs
        username = request.form.get("username")
        password = request.form.get("password")

        # Validate inputs
        if not username:
            return apology("must provide username", 400)
        elif not password:
            return apology("must provide password", 400)

        # Query the database for the user
        rows = db.execute("SELECT * FROM users WHERE username = ?", username)

        # Check if user exists and password matches
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], password):
            return apology("invalid username and/or password", 400)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect to the homepage
        return render_template("/index.html")

    # Show login form
    return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out"""
    session.clear()
    return render_template("login.html")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    if request.method == "POST":
        symbol = request.form.get("symbol")

        # Ensure symbol was provided
        if not symbol:
            return apology("must provide symbol", 400)

        # Lookup stock data
        stock = lookup(symbol)

        # If lookup returns None, symbol is invalid or API failed
        if stock is None:
            return apology("invalid symbol", 400)

        # Render the stock information
        message = f"A share of {stock['name']} ({stock['symbol']}) costs {usd(stock['price'])}."
        return render_template("quoted.html", stock=stock), 200

    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")

        # Ensure username and passwords were provided and passwords match
        if not username:
            return apology("must provide username", 400)
        elif not password:
            return apology("must provide password", 400)
        elif password != confirmation:
            return apology("passwords do not match", 400)

        # Hash the password and insert the new user into the database
        hash = generate_password_hash(password)
        try:
            db.execute("INSERT INTO users (username, hash, cash) VALUES (?, ?, ?)", username, hash, 10000)
        except ValueError:
            return apology("username already exists", 400)

        return redirect("/login")

    else:
        return render_template("register.html")

@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    if request.method == "POST":
        symbol = request.form.get("symbol")
        shares = request.form.get("shares")

        # Ensure symbol was provided
        if not symbol:
            return apology("must provide symbol", 400)

        # Ensure shares is a valid number
        if not shares or not shares.isdigit() or int(shares) <= 0:
            return apology("must provide positive number of shares", 400)

        # Check if user owns enough shares
        shares = int(shares)
        rows = db.execute("SELECT SUM(shares) AS total_shares FROM transactions WHERE user_id = ? AND symbol = ?",
                          session["user_id"], symbol.upper())

        if len(rows) != 1 or rows[0]["total_shares"] < shares:
            return apology("too many shares", 400)

        # Lookup stock price
        stock = lookup(symbol)
        if stock is None:
            return apology("invalid symbol", 400)

        # Calculate total sale value
        price = float(stock["price"])
        total_sale_value = price * shares

        # Update user's cash balance
        db.execute("UPDATE users SET cash = cash + ? WHERE id = ?", total_sale_value, session["user_id"])

        # Record the sale in transactions (negative shares for selling)
        db.execute("INSERT INTO transactions (user_id, symbol, shares, price, transacted) VALUES (?, ?, ?, ?, datetime('now'))",
                   session["user_id"], symbol.upper(), -shares, price)

        # Redirect to index after successful sale
        return redirect("/")

    else:
        rows = db.execute("SELECT symbol, SUM(shares) AS total_shares FROM transactions WHERE user_id = ? GROUP BY symbol HAVING total_shares > 0",
                          session["user_id"])
        return render_template("sell.html", stocks=[row["symbol"] for row in rows])


if __name__ == "__main__":
    app.run(debug=True)
